#ifndef _NETINET_IN_H
#define _NETINET_IN_H

#include <cygwin/in.h>

#endif /* _NETINET_IN_H */
