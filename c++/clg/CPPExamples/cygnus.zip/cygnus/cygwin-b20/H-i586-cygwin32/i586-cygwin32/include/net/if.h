#ifndef _NET_IF_H
#define _NET_IF_H

#include <cygwin/if.h>

#endif /* _NET_IF_H */
