#ifdef __cplusplus
extern "C" {
#endif
#include <sys/dirent.h>
#ifdef __cplusplus
}
#endif
